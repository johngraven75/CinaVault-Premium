// CinaVault Premium — Universal Plugin Registry
// All known MS-A, MS-B, and MS-C plugins pre-populated with CinaVault compatibility

export type PluginPlatform = "jellyfin" | "emby" | "plex" | "cinavault";
export type PluginCategory =
  | "metadata" | "subtitles" | "live_tv" | "notifications"
  | "management" | "channels" | "social" | "stats"
  | "artwork" | "utilities" | "themes" | "content_providers"
  | "playback" | "sync" | "security" | "ai";
export type PluginStatus = "available" | "installed" | "active" | "disabled" | "incompatible" | "update_available";

export interface PluginEntry {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  platforms: PluginPlatform[];
  category: PluginCategory;
  status: PluginStatus;
  icon: string;          // emoji or icon key
  repo?: string;         // GitHub URL
  configurable: boolean;
  premium: boolean;
  cinavaultNative: boolean;  // true = has CinaVault adapter built-in
  tags: string[];
}

// ═══════════════════════════════════════════════════════════
//  MS-C PLUGINS (Official + Community)
// ═══════════════════════════════════════════════════════════
const JELLYFIN_PLUGINS: PluginEntry[] = [
  // ── Metadata ──
  { id: "jf-anidb", name: "AniDB", description: "Fetch anime metadata from AniDB including episode info, character data, and series relationships.", version: "11.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🎌", repo: "https://github.com/MS-C/MS-C-plugin-anidb", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","metadata","scraper"] },
  { id: "jf-anilist", name: "AniList", description: "AniList metadata provider for anime series and movies with ratings and recommendations.", version: "8.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "📺", repo: "https://github.com/MS-C/MS-C-plugin-anilist", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","metadata","ratings"] },
  { id: "jf-anisearch", name: "AniSearch", description: "German anime database metadata provider with detailed series information.", version: "5.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🔍", repo: "https://github.com/MS-C/MS-C-plugin-anisearch", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","metadata","german"] },
  { id: "jf-kitsu", name: "Kitsu", description: "Kitsu.io anime/manga metadata with social features, episode guides, and community ratings.", version: "8.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🦊", repo: "https://github.com/MS-C/MS-C-plugin-kitsu", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","metadata","social"] },
  { id: "jf-tvdb", name: "TheTVDB", description: "Comprehensive TV series metadata from TheTVDB including episode listings, artwork, and actor info.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "📡", repo: "https://github.com/MS-C/MS-C-plugin-tvdb", configurable: true, premium: false, cinavaultNative: true, tags: ["tv","metadata","episodes"] },
  { id: "jf-tvmaze", name: "TVMaze", description: "TVMaze metadata provider with scheduling info, cast data, and show relationships.", version: "5.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🌐", repo: "https://github.com/MS-C/MS-C-plugin-tvmaze", configurable: true, premium: false, cinavaultNative: true, tags: ["tv","metadata","schedule"] },
  { id: "jf-tmdb-boxsets", name: "TMDb Box Sets", description: "Automatically create movie collections/box sets based on TMDb collection data.", version: "10.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "📦", repo: "https://github.com/MS-C/MS-C-plugin-tmdbboxsets", configurable: true, premium: false, cinavaultNative: true, tags: ["movies","collections","tmdb"] },
  { id: "jf-bookshelf", name: "Bookshelf", description: "eBook and audiobook metadata from Google Books, Open Library, and Comic Vine.", version: "10.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "📚", repo: "https://github.com/MS-C/MS-C-plugin-bookshelf", configurable: true, premium: false, cinavaultNative: true, tags: ["books","audiobooks","metadata"] },
  { id: "jf-imvdb", name: "IMVDb", description: "Internet Music Video Database metadata for music videos.", version: "5.0.0", author: "crobibero", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🎵", repo: "https://github.com/MS-C/MS-C-plugin-imvdb", configurable: true, premium: false, cinavaultNative: true, tags: ["music","videos","metadata"] },
  { id: "jf-vgmdb", name: "VGMDb", description: "Video game music database metadata provider.", version: "3.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "🎮", repo: "https://github.com/MS-C/MS-C-plugin-vgmdb", configurable: false, premium: false, cinavaultNative: true, tags: ["games","music","metadata"] },
  { id: "jf-comicvine", name: "Comic Vine", description: "Comic book metadata from Comic Vine including issue details and character info.", version: "3.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "metadata", status: "available", icon: "💥", repo: "https://github.com/MS-C/MS-C-plugin-bookshelf", configurable: true, premium: false, cinavaultNative: true, tags: ["comics","metadata"] },

  // ── Artwork ──
  { id: "jf-fanart", name: "Fanart.tv", description: "High-quality fan artwork for movies, TV, and music including clearart, logos, and backgrounds.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "artwork", status: "available", icon: "🎨", repo: "https://github.com/MS-C/MS-C-plugin-fanart", configurable: true, premium: false, cinavaultNative: true, tags: ["artwork","posters","fanart"] },
  { id: "jf-coverart", name: "Cover Art Archive", description: "Album artwork from MusicBrainz Cover Art Archive for music libraries.", version: "5.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "artwork", status: "available", icon: "🖼️", repo: "https://github.com/MS-C/MS-C-plugin-coverartarchive", configurable: false, premium: false, cinavaultNative: true, tags: ["music","artwork","covers"] },

  // ── Subtitles ──
  { id: "jf-opensubtitles", name: "Open Subtitles", description: "Download subtitles from OpenSubtitles.org with automatic language matching and hash-based search.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "subtitles", status: "available", icon: "💬", repo: "https://github.com/MS-C/MS-C-plugin-opensubtitles", configurable: true, premium: false, cinavaultNative: true, tags: ["subtitles","download","opensubtitles"] },
  { id: "jf-subtitle-extract", name: "Subtitle Extract", description: "Extract embedded subtitles from video files into external SRT/ASS files.", version: "5.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "subtitles", status: "available", icon: "📝", repo: "https://github.com/MS-C/MS-C-plugin-subtitle-extract", configurable: true, premium: false, cinavaultNative: true, tags: ["subtitles","extract","srt"] },
  { id: "jf-lrclib", name: "LrcLib Lyrics", description: "Fetch synchronized lyrics for music tracks from LrcLib.", version: "2.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "subtitles", status: "available", icon: "🎤", repo: "https://github.com/MS-C/MS-C-plugin-lrclib", configurable: false, premium: false, cinavaultNative: true, tags: ["music","lyrics","sync"] },

  // ── Live TV ──
  { id: "jf-nextpvr", name: "NextPVR", description: "Live TV and DVR integration with NextPVR server for recording and timeshift.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "live_tv", status: "available", icon: "📺", repo: "https://github.com/MS-C/MS-C-plugin-nextpvr", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","pvr","recording"] },
  { id: "jf-tvheadend", name: "TVHeadend", description: "Integration with TVHeadend server for live TV streaming and EPG data.", version: "10.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "live_tv", status: "available", icon: "📡", repo: "https://github.com/MS-C/MS-C-plugin-tvheadend", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","tvheadend","epg"] },
  { id: "jf-chapter-segments", name: "Chapter Segments Provider", description: "Automatic chapter/intro/outro segment detection for skip functionality.", version: "2.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "playback", status: "available", icon: "⏭️", repo: "https://github.com/MS-C/MS-C-plugin-chapter-segments", configurable: true, premium: false, cinavaultNative: true, tags: ["chapters","skip","intro"] },

  // ── Sync & Social ──
  { id: "jf-trakt", name: "Trakt", description: "Sync watched history, ratings, and watchlist with Trakt.tv across all your media apps.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "sync", status: "available", icon: "🔄", repo: "https://github.com/MS-C/MS-C-plugin-trakt", configurable: true, premium: false, cinavaultNative: true, tags: ["trakt","sync","history"] },
  { id: "jf-simkl", name: "Simkl", description: "Scrobble watched media to Simkl with automatic tracking and ratings sync.", version: "3.0.0", author: "crobibero", platforms: ["jellyfin","cinavault"], category: "sync", status: "available", icon: "📊", repo: "https://github.com/MS-C/MS-C-plugin-simkl", configurable: true, premium: false, cinavaultNative: true, tags: ["simkl","scrobble","tracking"] },
  { id: "jf-kodi-sync", name: "Kodi Sync Queue", description: "Sync all media changes with Kodi clients for real-time library updates.", version: "10.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "sync", status: "available", icon: "🔗", repo: "https://github.com/MS-C/MS-C-plugin-kodisyncqueue", configurable: true, premium: false, cinavaultNative: true, tags: ["kodi","sync","queue"] },
  { id: "jf-infusesync", name: "InfuseSync", description: "Track media changes for Infuse clients to decrease sync times.", version: "5.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "sync", status: "available", icon: "🔄", configurable: false, premium: false, cinavaultNative: true, tags: ["infuse","sync","apple"] },

  // ── Notifications ──
  { id: "jf-webhook", name: "Webhook", description: "Send notifications via webhook to any HTTP endpoint — Discord, Slack, Gotify, Pushover, and more.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "notifications", status: "available", icon: "🔔", repo: "https://github.com/MS-C/MS-C-plugin-webhook", configurable: true, premium: false, cinavaultNative: true, tags: ["webhook","discord","notifications"] },

  // ── Management & Utilities ──
  { id: "jf-reports", name: "Reports", description: "Generate detailed reports of your media library including statistics and missing metadata.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "stats", status: "available", icon: "📈", repo: "https://github.com/MS-C/MS-C-plugin-reports", configurable: false, premium: false, cinavaultNative: true, tags: ["reports","statistics","library"] },
  { id: "jf-playback-reporting", name: "Playback Reporting", description: "Collect and display user playback statistics with graphs and detailed activity logs.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "stats", status: "available", icon: "📊", repo: "https://github.com/MS-C/MS-C-plugin-playbackreporting", configurable: true, premium: false, cinavaultNative: true, tags: ["playback","stats","analytics"] },
  { id: "jf-session-cleaner", name: "Session Cleaner", description: "Automatically remove old/stale sessions and device entries to keep your server clean.", version: "3.0.0", author: "crobibero", platforms: ["jellyfin","cinavault"], category: "management", status: "available", icon: "🧹", repo: "https://github.com/MS-C/MS-C-plugin-sessioncleaner", configurable: true, premium: false, cinavaultNative: true, tags: ["sessions","cleanup","management"] },
  { id: "jf-ldap", name: "LDAP Authentication", description: "Authenticate users against an LDAP/Active Directory server for enterprise environments.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "security", status: "available", icon: "🔐", repo: "https://github.com/MS-C/MS-C-plugin-ldap", configurable: true, premium: false, cinavaultNative: true, tags: ["ldap","auth","enterprise"] },
  { id: "jf-dlna", name: "DLNA", description: "DLNA server and renderer support for streaming to compatible devices on your network.", version: "13.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "utilities", status: "available", icon: "📡", repo: "https://github.com/MS-C/MS-C-plugin-dlna", configurable: true, premium: false, cinavaultNative: true, tags: ["dlna","streaming","network"] },
  { id: "jf-opds", name: "OPDS", description: "OPDS catalog server for eBooks allowing access from OPDS-compatible readers.", version: "3.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "utilities", status: "available", icon: "📖", configurable: true, premium: false, cinavaultNative: true, tags: ["books","opds","catalog"] },
  { id: "jf-transcode-killer", name: "Transcode Killer", description: "Automatically kill transcode sessions based on configurable rules and thresholds.", version: "2.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "management", status: "available", icon: "⚡", configurable: true, premium: false, cinavaultNative: true, tags: ["transcode","performance","management"] },
  { id: "jf-local-intros", name: "Local Intros", description: "Play local video files as pre-roll intros before movies — custom theater experience.", version: "2.0.0", author: "MS-C Team", platforms: ["jellyfin","cinavault"], category: "playback", status: "available", icon: "🎬", configurable: true, premium: false, cinavaultNative: true, tags: ["intros","preroll","cinema"] },
  { id: "jf-tmdb-trailers", name: "TMDb Trailers", description: "Watch trailers from TMDb directly within your media server interface.", version: "3.0.0", author: "crobibero", platforms: ["jellyfin","cinavault"], category: "channels", status: "available", icon: "🎥", configurable: false, premium: false, cinavaultNative: true, tags: ["trailers","tmdb","preview"] },
];

// ═══════════════════════════════════════════════════════════
//  MS-B PLUGINS (Official + 3rd Party)
// ═══════════════════════════════════════════════════════════
const EMBY_PLUGINS: PluginEntry[] = [
  // ── Metadata ──
  { id: "em-cover-art", name: "Cover Art", description: "Enhance media images with dynamic overlays, badges, and custom artwork generation.", version: "4.8.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "artwork", status: "available", icon: "🖼️", configurable: true, premium: false, cinavaultNative: true, tags: ["artwork","covers","overlays"] },
  { id: "em-gamebrowser", name: "GameBrowser", description: "Adds game support to your media server — browse, launch, and manage video game collections.", version: "3.2.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "content_providers", status: "available", icon: "🎮", configurable: true, premium: false, cinavaultNative: true, tags: ["games","browser","emulator"] },
  { id: "em-trailers", name: "Trailers", description: "Stream internet trailers for movies and upcoming releases with automatic updates.", version: "6.1.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "channels", status: "available", icon: "🎬", configurable: true, premium: false, cinavaultNative: true, tags: ["trailers","movies","streaming"] },
  { id: "em-trakt", name: "Trakt for MS-B", description: "Full Trakt.tv integration with automatic scrobbling, ratings sync, and watchlist import.", version: "5.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "sync", status: "available", icon: "🔄", configurable: true, premium: false, cinavaultNative: true, tags: ["trakt","sync","scrobble"] },
  { id: "em-bookshelf", name: "Bookshelf", description: "eBook and audiobook metadata provider with support for ePub, PDF, and audiobook formats.", version: "2.5.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "metadata", status: "available", icon: "📚", configurable: true, premium: false, cinavaultNative: true, tags: ["books","audiobooks","epub"] },
  { id: "em-auto-organize", name: "Auto Organize", description: "Automatically sort downloaded media into the correct library folders with smart naming.", version: "8.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "management", status: "available", icon: "📁", configurable: true, premium: false, cinavaultNative: true, tags: ["organize","rename","sort"] },

  // ── Notifications ──
  { id: "em-email-notify", name: "Email Notifications", description: "Send SMTP email notifications for new content, playback events, and server alerts.", version: "5.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "📧", configurable: true, premium: false, cinavaultNative: true, tags: ["email","smtp","notifications"] },
  { id: "em-pushbullet", name: "Pushbullet", description: "Push notifications to your devices via Pushbullet for media server events.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "📲", configurable: true, premium: false, cinavaultNative: true, tags: ["pushbullet","notifications","push"] },
  { id: "em-pushover", name: "Pushover", description: "Send rich notifications via Pushover with priority levels and custom sounds.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "🔔", configurable: true, premium: false, cinavaultNative: true, tags: ["pushover","notifications","priority"] },
  { id: "em-slack-notify", name: "Slack Notifications", description: "Send notifications via incoming webhooks to the Slack channel of your choice.", version: "2.5.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "💬", configurable: true, premium: false, cinavaultNative: true, tags: ["slack","webhook","notifications"] },
  { id: "em-discord-notify", name: "Discord Notifications", description: "Send rich embed notifications to Discord channels via webhooks.", version: "2.0.0", author: "Community", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "🎮", repo: "https://github.com/Techsmith404/MS-B-Plugins-List", configurable: true, premium: false, cinavaultNative: true, tags: ["discord","webhook","notifications"] },
  { id: "em-gotify", name: "Gotify Notification", description: "Send notifications to your self-hosted Gotify server for privacy-focused alerts.", version: "2.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "notifications", status: "available", icon: "🔔", configurable: true, premium: false, cinavaultNative: true, tags: ["gotify","selfhosted","notifications"] },

  // ── Live TV ──
  { id: "em-dvblink", name: "DVBLink", description: "Live TV integration with DVBLink server for digital TV tuners.", version: "4.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "📺", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","dvblink","tuner"] },
  { id: "em-dvbviewer", name: "DVBViewer", description: "Integration with DVBViewer Recording Service for live TV and EPG.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "📡", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","dvbviewer","epg"] },
  { id: "em-nextpvr", name: "NextPVR for MS-B", description: "Live TV and DVR functionality via NextPVR backend.", version: "5.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "⏺️", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","nextpvr","dvr"] },
  { id: "em-serverwmc", name: "ServerWMC", description: "Windows Media Center TV integration for live TV and recordings.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "🖥️", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","wmc","windows"] },
  { id: "em-tvheadend", name: "TVHeadend for MS-B", description: "TVHeadend backend integration for live TV and guide data.", version: "4.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "📡", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","tvheadend","guide"] },
  { id: "em-tvmosaic", name: "TVMosaic", description: "TVMosaic live TV backend with multi-tuner support and cloud DVR.", version: "2.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "🧩", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","tvmosaic","dvr"] },
  { id: "em-vuplus", name: "Vu+", description: "Vu+ STB integration for satellite and IPTV channel access.", version: "2.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "📡", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","vu","satellite"] },
  { id: "em-mediaportal", name: "MediaPortal", description: "MediaPortal TV Server integration for live TV and recordings.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "live_tv", status: "available", icon: "🌀", configurable: true, premium: false, cinavaultNative: true, tags: ["livetv","mediaportal","pvr"] },

  // ── 3rd Party Management & Utilities ──
  { id: "em-smart-playlists", name: "Smart Playlists 2.0", description: "Create dynamic playlists based on tags, genres, ratings, and custom rules.", version: "2.0.0", author: "Community", platforms: ["emby","cinavault"], category: "management", status: "available", icon: "📋", repo: "https://github.com/Techsmith404/MS-B-Plugins-List", configurable: true, premium: false, cinavaultNative: true, tags: ["playlists","smart","dynamic"] },
  { id: "em-iconic", name: "Iconic Image Enhancer", description: "Add resolution, HDR, Dolby, and codec badges to cover art automatically.", version: "1.5.0", author: "Community", platforms: ["emby","cinavault"], category: "artwork", status: "available", icon: "🏷️", configurable: true, premium: false, cinavaultNative: true, tags: ["badges","hdr","artwork"] },
  { id: "em-watch-party", name: "MS-B Party", description: "Watch together feature — synchronized playback across multiple users.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "social", status: "available", icon: "🎉", configurable: true, premium: false, cinavaultNative: true, tags: ["watchparty","social","sync"] },
  { id: "em-virtual-tv", name: "VirtualTV", description: "Create custom virtual TV channels from your media library with scheduling.", version: "2.0.0", author: "Community", platforms: ["emby","cinavault"], category: "channels", status: "available", icon: "📺", configurable: true, premium: false, cinavaultNative: true, tags: ["virtualtv","channels","schedule"] },
  { id: "em-pseudo-tv", name: "PseudoTV", description: "Simulate real TV channels with commercial breaks from your media library.", version: "1.5.0", author: "Community", platforms: ["emby","cinavault"], category: "channels", status: "available", icon: "🖥️", configurable: true, premium: false, cinavaultNative: true, tags: ["pseudotv","channels","simulation"] },
  { id: "em-bulky", name: "Bulky", description: "Mass metadata editor — batch edit tags, genres, ratings, and other metadata fields.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "management", status: "available", icon: "✏️", configurable: true, premium: false, cinavaultNative: true, tags: ["batch","editor","metadata"] },
  { id: "em-movie-merge", name: "Movie Auto Merge", description: "Automatically merge duplicate movie entries and combine multi-edition files.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "management", status: "available", icon: "🔀", configurable: true, premium: false, cinavaultNative: true, tags: ["merge","duplicates","cleanup"] },
  { id: "em-m3u-export", name: "Export VODs from M3U", description: "Split M3U files to extract live TV, TV shows, and movie entries separately.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "utilities", status: "available", icon: "📄", configurable: true, premium: false, cinavaultNative: true, tags: ["m3u","iptv","export"] },
  { id: "em-webstreams", name: "WebStreams", description: "Add web-based video and audio streams as channels in your library.", version: "3.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "channels", status: "available", icon: "🌐", configurable: true, premium: false, cinavaultNative: true, tags: ["webstreams","channels","iptv"] },
  { id: "em-live-translate", name: "Live Video Translation", description: "Generate translated subtitles on the fly during playback using AI.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "subtitles", status: "available", icon: "🌍", configurable: true, premium: true, cinavaultNative: true, tags: ["translate","ai","subtitles"] },
  { id: "em-watch-history", name: "Watch History Channel", description: "Display what other users are currently watching in a dedicated channel.", version: "1.0.0", author: "Community", platforms: ["emby","cinavault"], category: "social", status: "available", icon: "👁️", configurable: false, premium: false, cinavaultNative: true, tags: ["history","social","activity"] },
  { id: "em-onedrive", name: "OneDrive", description: "Cloud storage integration with Microsoft OneDrive for remote media access.", version: "2.0.0", author: "MS-B Team", platforms: ["emby","cinavault"], category: "utilities", status: "available", icon: "☁️", configurable: true, premium: false, cinavaultNative: true, tags: ["onedrive","cloud","storage"] },
];

// ═══════════════════════════════════════════════════════════
//  MS-A PLUGINS / TOOLS (Working tools and community add-ons)
// ═══════════════════════════════════════════════════════════
const PLEX_PLUGINS: PluginEntry[] = [
  // ── Management ──
  { id: "px-tautulli", name: "Tautulli", description: "Comprehensive MS-A monitoring dashboard with playback stats, user activity, notifications, and newsletters.", version: "2.14.0", author: "Tautulli Team", platforms: ["plex","cinavault"], category: "stats", status: "available", icon: "📊", repo: "https://github.com/Tautulli/Tautulli", configurable: true, premium: false, cinavaultNative: true, tags: ["stats","monitoring","analytics"] },
  { id: "px-kitana", name: "Kitana", description: "Plugin manager for MS-A — install, update, and manage plugins from a web interface.", version: "1.2.0", author: "pannal", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "⚔️", repo: "https://github.com/pannal/Kitana", configurable: true, premium: false, cinavaultNative: true, tags: ["manager","plugins","admin"] },
  { id: "px-webtools", name: "WebTools", description: "Administrative toolkit for MS-A with subtitle management, log viewer, and plugin manager.", version: "4.0.0", author: "WebTools-NG", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🔧", repo: "https://github.com/WebTools-NG/WebTools-NG", configurable: true, premium: false, cinavaultNative: true, tags: ["admin","tools","subtitles"] },
  { id: "px-overseerr", name: "Overseerr", description: "Request management and media discovery tool for MS-A with beautiful UI and user management.", version: "1.33.0", author: "sct", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🎯", repo: "https://github.com/sct/overseerr", configurable: true, premium: false, cinavaultNative: true, tags: ["requests","discovery","management"] },
  { id: "px-ombi", name: "Ombi", description: "Media request system — users can request movies and TV shows to be added to your library.", version: "4.44.0", author: "Ombi Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "📩", repo: "https://github.com/Ombi-app/Ombi", configurable: true, premium: false, cinavaultNative: true, tags: ["requests","ombi","users"] },
  { id: "px-kometa", name: "Kometa (MS-A Meta Manager)", description: "Automated collection management with smart filters, overlays, and custom poster generation.", version: "2.1.0", author: "Kometa Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🏷️", repo: "https://github.com/Kometa-Team/Kometa", configurable: true, premium: false, cinavaultNative: true, tags: ["collections","overlays","metadata"] },

  // ── Subtitles ──
  { id: "px-bazarr", name: "Bazarr", description: "Automated subtitle downloader from 25+ providers with language matching and auto-updates.", version: "1.4.0", author: "morpheus65535", platforms: ["plex","cinavault"], category: "subtitles", status: "available", icon: "💬", repo: "https://github.com/morpheus65535/bazarr", configurable: true, premium: false, cinavaultNative: true, tags: ["subtitles","bazarr","automated"] },
  { id: "px-sub-zero", name: "Sub-Zero", description: "Advanced subtitle management — auto-download, fix timing, add colors, and modify existing subs.", version: "2.6.0", author: "pannal", platforms: ["plex","cinavault"], category: "subtitles", status: "available", icon: "🥶", repo: "https://github.com/pannal/Sub-Zero.bundle", configurable: true, premium: false, cinavaultNative: true, tags: ["subtitles","fix","management"] },

  // ── Sync & Social ──
  { id: "px-trakt-scrobbler", name: "MS-A-Trakt-Scrobbler", description: "Automatic scrobbling of watched content to Trakt.tv with full history sync.", version: "3.0.0", author: "trakt", platforms: ["plex","cinavault"], category: "sync", status: "available", icon: "🔄", repo: "https://github.com/trakt/MS-A-Trakt-Scrobbler", configurable: true, premium: false, cinavaultNative: true, tags: ["trakt","scrobble","sync"] },
  { id: "px-MS-A-sync", name: "MS-A-Sync", description: "Synchronize watch status and libraries across multiple MS-A servers.", version: "1.5.0", author: "jacobwgillespie", platforms: ["plex","cinavault"], category: "sync", status: "available", icon: "🔗", repo: "https://github.com/jacobwgillespie/MS-A-sync", configurable: true, premium: false, cinavaultNative: true, tags: ["sync","multiserver","watchstatus"] },

  // ── Content & Channels ──
  { id: "px-iptv", name: "IPTV for MS-A", description: "Stream live TV via M3U playlists with EPG support and channel management.", version: "2.0.0", author: "Cigaras", platforms: ["plex","cinavault"], category: "channels", status: "available", icon: "📺", repo: "https://github.com/Cigaras/IPTV.bundle", configurable: true, premium: false, cinavaultNative: true, tags: ["iptv","livetv","m3u"] },
  { id: "px-lambda", name: "Lambda", description: "Metadata agent with enhanced matching and comprehensive media identification.", version: "2.0.0", author: "Lambda", platforms: ["plex","cinavault"], category: "metadata", status: "available", icon: "λ", configurable: true, premium: false, cinavaultNative: true, tags: ["metadata","agent","matching"] },
  { id: "px-hama", name: "HAMA (HTTP Anidb Metadata Agent)", description: "Comprehensive anime metadata agent combining AniDB, MAL, TVDB, and AniList data.", version: "3.0.0", author: "ZeroQI", platforms: ["plex","cinavault"], category: "metadata", status: "available", icon: "🎌", repo: "https://github.com/ZeroQI/Hama.bundle", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","metadata","hama"] },
  { id: "px-ass", name: "Absolute Series Scanner", description: "Enhanced scanner for anime and comMS-A series structures with absolute numbering support.", version: "3.0.0", author: "ZeroQI", platforms: ["plex","cinavault"], category: "metadata", status: "available", icon: "🔢", repo: "https://github.com/ZeroQI/Absolute-Series-Scanner", configurable: true, premium: false, cinavaultNative: true, tags: ["anime","scanner","series"] },

  // ── Utilities ──
  { id: "px-filebot", name: "FileBot", description: "Smart media renaming and organization tool with metadata-driven file naming.", version: "5.1.0", author: "FileBot", platforms: ["plex","cinavault"], category: "utilities", status: "available", icon: "🤖", configurable: true, premium: false, cinavaultNative: true, tags: ["rename","organize","filebot"] },
  { id: "px-transmogrify", name: "Transmogrify", description: "Browser extension adding trailers, Rotten Tomatoes ratings, and missing episodes to MS-A Web.", version: "1.8.0", author: "Transmogrify", platforms: ["plex","cinavault"], category: "utilities", status: "available", icon: "🔮", configurable: false, premium: false, cinavaultNative: true, tags: ["browser","extension","ratings"] },
  { id: "px-openpht", name: "OpenPHT", description: "Open source MS-A Home Theater with customizable skins and interfaces.", version: "1.8.0", author: "RasMS-A", platforms: ["plex","cinavault"], category: "themes", status: "available", icon: "🎨", configurable: true, premium: false, cinavaultNative: true, tags: ["player","skins","theater"] },
  { id: "px-MS-Aamp", name: "MS-Aamp Integration", description: "Audiophile music player features — gapless playback, FLAC support, loudness normalization.", version: "4.10.0", author: "plex", platforms: ["plex","cinavault"], category: "playback", status: "available", icon: "🎵", configurable: true, premium: false, cinavaultNative: true, tags: ["music","audiophile","MS-Aamp"] },

  // ── Automation & Download ──
  { id: "px-sonarr", name: "Sonarr", description: "Automatic TV show monitoring, downloading, and library management integration.", version: "4.0.0", author: "Sonarr Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "📡", repo: "https://github.com/Sonarr/Sonarr", configurable: true, premium: false, cinavaultNative: true, tags: ["sonarr","automation","tv"] },
  { id: "px-radarr", name: "Radarr", description: "Automatic movie monitoring, downloading, and organization integration.", version: "5.0.0", author: "Radarr Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🎬", repo: "https://github.com/Radarr/Radarr", configurable: true, premium: false, cinavaultNative: true, tags: ["radarr","automation","movies"] },
  { id: "px-lidarr", name: "Lidarr", description: "Automatic music collection manager and downloader integration.", version: "2.0.0", author: "Lidarr Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🎶", repo: "https://github.com/Lidarr/Lidarr", configurable: true, premium: false, cinavaultNative: true, tags: ["lidarr","music","automation"] },
  { id: "px-readarr", name: "Readarr", description: "Automatic eBook and audiobook collection manager integration.", version: "0.3.0", author: "Readarr Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "📖", repo: "https://github.com/Readarr/Readarr", configurable: true, premium: false, cinavaultNative: true, tags: ["readarr","books","automation"] },
  { id: "px-prowlarr", name: "Prowlarr", description: "Universal indexer manager that integrates with Sonarr, Radarr, Lidarr, and Readarr.", version: "1.0.0", author: "Prowlarr Team", platforms: ["plex","cinavault"], category: "management", status: "available", icon: "🔍", repo: "https://github.com/Prowlarr/Prowlarr", configurable: true, premium: false, cinavaultNative: true, tags: ["prowlarr","indexer","automation"] },
];

// ═══════════════════════════════════════════════════════════
//  CINAVAULT-NATIVE PLUGINS (Built-in exclusive features)
// ═══════════════════════════════════════════════════════════
const CINAVAULT_NATIVE: PluginEntry[] = [
  { id: "cv-unified-adapter", name: "CinaVault Unified Plugin Adapter", description: "Core compatibility layer that translates MS-C, MS-B, and MS-A plugin APIs to CinaVault's unified plugin interface. Enables cross-platform plugin usage.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "utilities", status: "active", icon: "🔌", configurable: true, premium: false, cinavaultNative: true, tags: ["adapter","compatibility","core"] },
  { id: "cv-metadata-engine", name: "CinaVault Metadata Engine", description: "Unified metadata aggregator pulling from 30+ providers simultaneously with smart conflict resolution and merge logic.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "metadata", status: "active", icon: "🧠", configurable: true, premium: true, cinavaultNative: true, tags: ["metadata","aggregator","smart"] },
  { id: "cv-ai-match", name: "AI Media Matcher", description: "AI-powered media identification using file analysis, audio fingerprinting, and visual recognition.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "ai", status: "active", icon: "🤖", configurable: true, premium: true, cinavaultNative: true, tags: ["ai","matching","fingerprint"] },
  { id: "cv-cloud-sync", name: "Cloud Sync Engine", description: "Real-time bidirectional sync with OneDrive, Google Drive, and Dropbox with intelligent caching.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "sync", status: "active", icon: "☁️", configurable: true, premium: true, cinavaultNative: true, tags: ["cloud","sync","onedrive","gdrive"] },
  { id: "cv-thumb-gen", name: "Smart Thumbnail Generator", description: "AI-enhanced thumbnail generation with scene detection, face recognition, and composition scoring.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "artwork", status: "active", icon: "🖼️", configurable: true, premium: true, cinavaultNative: true, tags: ["thumbnails","ai","generation"] },
  { id: "cv-chapter-detect", name: "Chapter Image Detector", description: "Automated chapter image extraction and scene boundary detection using video analysis.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "playback", status: "active", icon: "📸", configurable: true, premium: true, cinavaultNative: true, tags: ["chapters","images","detection"] },
  { id: "cv-dup-finder", name: "Duplicate Finder", description: "Find and manage duplicate media files across all sources using hash comparison and metadata analysis.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "management", status: "active", icon: "🔍", configurable: true, premium: true, cinavaultNative: true, tags: ["duplicates","cleanup","hash"] },
  { id: "cv-vpn-manager", name: "VPN Manager", description: "Built-in VPN integration with automatic connection management and kill switch.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "security", status: "active", icon: "🛡️", configurable: true, premium: true, cinavaultNative: true, tags: ["vpn","privacy","security"] },
  { id: "cv-transcode-engine", name: "Hardware Transcode Engine", description: "GPU-accelerated transcoding with NVENC, QSV, and VAAPI support with automatic codec detection.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "playback", status: "active", icon: "⚡", configurable: true, premium: true, cinavaultNative: true, tags: ["transcode","gpu","hardware"] },
  { id: "cv-intro-skip", name: "Intro/Outro Skip Engine", description: "Automatic intro and outro detection with one-click skip and chromaprint audio matching.", version: "1.0.0", author: "CinaVault", platforms: ["cinavault"], category: "playback", status: "active", icon: "⏭️", configurable: true, premium: true, cinavaultNative: true, tags: ["skip","intro","outro"] },
];

// ── Combined Full Registry ──
export const FULL_PLUGIN_REGISTRY: PluginEntry[] = [
  ...CINAVAULT_NATIVE,
  ...JELLYFIN_PLUGINS,
  ...EMBY_PLUGINS,
  ...PLEX_PLUGINS,
];

// ── Helper: get all categories ──
export const ALL_CATEGORIES: PluginCategory[] = [
  "metadata", "subtitles", "live_tv", "notifications", "management",
  "channels", "social", "stats", "artwork", "utilities",
  "themes", "content_providers", "playback", "sync", "security", "ai",
];

// ── Helper: category labels ──
export const CATEGORY_LABELS: Record<PluginCategory, string> = {
  metadata: "Metadata Providers",
  subtitles: "Subtitles",
  live_tv: "Live TV & DVR",
  notifications: "Notifications",
  management: "Management & Automation",
  channels: "Channels & Streams",
  social: "Social & Sharing",
  stats: "Statistics & Reporting",
  artwork: "Artwork & Images",
  utilities: "Utilities & Tools",
  themes: "Themes & UI",
  content_providers: "Content Providers",
  playback: "Playback & Transcoding",
  sync: "Sync & Integration",
  security: "Security & Privacy",
  ai: "AI & Intelligence",
};

// ── Helper: platform labels ──
export const PLATFORM_LABELS: Record<PluginPlatform, string> = {
  jellyfin: "jellyfin",
  emby: "emby",
  plex: "plex",
  cinavault: "CinaVault Native",
};

export const PLATFORM_COLORS: Record<PluginPlatform, string> = {
  jellyfin: "#6b4c9a",
  emby: "#4caf50",
  plex: "#e5a00d",
  cinavault: "#06b6d4",
};
