import type { PluginEntry } from "../data/pluginRegistry";
import type { MetadataProvider } from "../store/appStore";

type MetadataProviderLike = Partial<MetadataProvider> | null | undefined;
type PluginSearchCandidate = Partial<Pick<PluginEntry, "name" | "description" | "tags">>;
type PluginRuntimeState = { id?: unknown; enabled?: unknown } | null | undefined;
type PluginStatusCandidate = Pick<PluginEntry, "id" | "status"> & Partial<Pick<PluginEntry, "cinavaultNative">>;

export function normalizeMetadataProviderId(id: string): string {
  switch (id.trim().toLowerCase()) {
    case "theporndb":
      return "tpdb";
    case "fanarttv":
      return "fanart";
    case "rotten_tomatoes":
      return "rt";
    case "myanimelist":
      return "mal";
    case "epg_guide":
      return "epg";
    default:
      return id.trim().toLowerCase();
  }
}

export function matchesPluginSearch(plugin: PluginSearchCandidate, rawSearch: string): boolean {
  const search = rawSearch.trim().toLowerCase();
  if (!search) return true;

  const name = typeof plugin.name === "string" ? plugin.name.toLowerCase() : "";
  const description = typeof plugin.description === "string" ? plugin.description.toLowerCase() : "";
  const tags = Array.isArray(plugin.tags)
    ? plugin.tags.filter((tag): tag is string => typeof tag === "string").map((tag) => tag.toLowerCase())
    : [];

  return name.includes(search) || description.includes(search) || tags.some((tag) => tag.includes(search));
}

export function getMetadataProviderInitials(name?: string | null): string {
  const trimmed = typeof name === "string" ? name.trim() : "";
  return trimmed ? trimmed.slice(0, 2).toUpperCase() : "??";
}

export function sanitizeMetadataProviders(
  persisted: unknown,
  defaults: MetadataProvider[],
): MetadataProvider[] {
  const merged = new Map<string, MetadataProvider>(
    defaults.map((provider) => [provider.id, { ...provider }]),
  );

  if (!Array.isArray(persisted)) {
    return Array.from(merged.values());
  }

  for (const candidate of persisted as MetadataProviderLike[]) {
    if (!candidate || typeof candidate !== "object" || typeof candidate.id !== "string") {
      continue;
    }

    const normalizedId = normalizeMetadataProviderId(candidate.id);
    const fallback = merged.get(normalizedId);
    const name = typeof candidate.name === "string" && candidate.name.trim()
      ? candidate.name.trim()
      : fallback?.name;
    const category = typeof candidate.category === "string" && candidate.category.trim()
      ? candidate.category.trim()
      : fallback?.category;

    if (!name || !category) {
      continue;
    }

    merged.set(normalizedId, {
      id: normalizedId,
      name,
      category,
      enabled: typeof candidate.enabled === "boolean" ? candidate.enabled : fallback?.enabled ?? false,
    });
  }

  return Array.from(merged.values());
}

export function enableAdultMetadataProviders(providers: MetadataProvider[]): MetadataProvider[] {
  return providers.map((provider) =>
    provider.category === "Adult" ? { ...provider, enabled: true } : provider,
  );
}

export function applyPluginRuntimeState<T extends PluginStatusCandidate>(
  registry: T[],
  installed: PluginRuntimeState[],
): T[] {
  const installedById = new Map<string, { enabled: boolean }>();

  for (const plugin of installed) {
    if (!plugin || typeof plugin.id !== "string" || !plugin.id.trim()) continue;
    installedById.set(plugin.id, {
      enabled: plugin.enabled !== false,
    });
  }

  return registry.map((plugin) => {
    const runtime = installedById.get(plugin.id);
    if (!runtime) return { ...plugin };

    return {
      ...plugin,
      status: runtime.enabled
        ? (plugin.cinavaultNative ? "active" : "installed")
        : "disabled",
    };
  });
}

export function getUnreadStatusMessages(messages: string[], lastReadIndex: number): string[] {
  const safeIndex = Number.isFinite(lastReadIndex) ? Math.max(0, Math.floor(lastReadIndex)) : 0;
  return messages.slice(Math.min(safeIndex + 1, messages.length));
}
